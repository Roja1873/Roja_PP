package com.capg.service;

import com.capg.exceptions.AccountAlreadyExistsException;
import com.capg.exceptions.AccountNotFoundException;
import com.capg.exceptions.LowBalanceException;

public interface BankServiceImpl {

	public boolean createAccount(String name, String add, long accNo, String phone, int pin, int bal)
			throws AccountAlreadyExistsException;

	public int showBalance(long accNo) throws AccountNotFoundException;

	public int deposit(long accNo, int deposit_amount) throws AccountNotFoundException;

	public int withdraw(long accNo, int withdraw_amount) throws AccountNotFoundException, LowBalanceException;

	public boolean transferfund(long accNo, long accNo1, int transfer_amount)
			throws AccountNotFoundException, LowBalanceException;

	public boolean validateBalance(long accNo, int amount) throws LowBalanceException;

	public String setTrans(long accNo) throws AccountNotFoundException;

}
